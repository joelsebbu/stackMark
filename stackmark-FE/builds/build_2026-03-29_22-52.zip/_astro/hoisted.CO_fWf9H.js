import"./ViewTransitions.astro_astro_type_script_index_0_lang.BScVxmeO.js";document.addEventListener("astro:page-load",()=>{const i=document.getElementById("search-input"),c=document.getElementById("search-btn"),s=document.getElementById("results-area");if(!i||!c||!s)return;const l="http://localhost:8000";function t(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function u(e){if(e.length===0){s.innerHTML=`
          <div class="empty-state">
            <p>No results found</p>
            <span>Try a different query</span>
          </div>`;return}s.innerHTML=e.map(a=>{const n=a.metadata||{},m=(n.tags||[]).slice(0,4),p=a.similarity!=null?`${Math.round(a.similarity*100)}%`:"",r=n.description||"",g=a.source||"web",d=a.url||"";return`
          <div class="result-card">
            <div class="card-header">
              <span class="card-title">${t(r.slice(0,80))}${r.length>80?"...":""}</span>
              ${p?`<span class="card-score">${p} match</span>`:""}
            </div>
            ${r.length>80?`<p class="card-description">${t(r.slice(0,200))}${r.length>200?"...":""}</p>`:""}
            <div class="card-meta">
              <span class="card-source">${t(g)}</span>
              ${m.map(h=>`<span class="card-tag">${t(h)}</span>`).join("")}
            </div>
            ${d?`<a class="card-url" href="${t(d)}" target="_blank" rel="noopener">${t(d)}</a>`:""}
          </div>`}).join("")}async function o(){const e=i.value.trim();if(e){c.disabled=!0,s.innerHTML='<div class="loading">Searching...</div>';try{const n=await(await fetch(`${l}/search`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:e,top_k:10})})).json();n.success?u(n.data||[]):s.innerHTML=`
            <div class="empty-state">
              <p>Error</p>
              <span>${t(n.error||"Something went wrong")}</span>
            </div>`}catch{s.innerHTML=`
          <div class="empty-state">
            <p>Could not reach the server</p>
            <span>Make sure the backend is running on ${l}</span>
          </div>`}finally{c.disabled=!1}}}c.addEventListener("click",o),i.addEventListener("keydown",e=>{e.key==="Enter"&&o()})});
